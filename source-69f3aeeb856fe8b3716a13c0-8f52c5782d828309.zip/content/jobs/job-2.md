---
jobTitle: Data Science Intern
company: Analytics Studio
location: New York, NY (Hybrid)
startDate: 2022-09-01
endDate: 2023-05-31
summary: Assisted the data team with exploratory analysis, dashboard creation, and model prototyping. Gained hands-on experience with the full data science workflow from raw data to stakeholder reporting.
description:
tags:
  [
    "Python",
    "Pandas",
    "Scikit-learn",
    "SQL",
    "Jupyter",
  ]
---

- Cleaned and transformed datasets of 500K+ rows using Pandas and SQL for downstream analysis
- Built a classification model prototype (scikit-learn) to flag anomalies in transaction data
- Created interactive dashboards for business stakeholders to explore key metrics
- Participated in weekly data reviews, presenting findings to non-technical audiences
