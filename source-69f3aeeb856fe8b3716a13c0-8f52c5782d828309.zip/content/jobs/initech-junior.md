---
jobTitle: Junior Automation Engineer
company: TechCorp Solutions
location: Remote
startDate: 2023-06-01
endDate: "Present"
summary: Built and maintained Python automation scripts that reduced manual data-entry time by 40%. Designed REST API integrations to sync data between internal tools and third-party platforms.
description:
tags:
  [
    "Python",
    "REST APIs",
    "Automation",
    "PostgreSQL",
    "Docker",
  ]
---

- Developed Python scripts to automate recurring ETL workflows, replacing manual spreadsheet processes
- Integrated Slack and Jira APIs for automated team notifications and issue tracking
- Wrote unit and integration tests to ensure reliability of automation pipelines
- Documented all integrations in Confluence for team knowledge sharing
