---
school: University of Placeholder City
summary: B.Sc. Computer Science — Focus on Data Systems & Software Engineering
startDate: 2019-09-01
endDate: 2023-05-31
tags:
  [
    "Algorithms",
    "Databases",
    "Machine Learning",
    "Software Engineering",
    "Statistics",
  ]
---

Graduated with a focus on data systems and applied software engineering. Completed coursework in algorithms, relational databases, machine learning fundamentals, and statistics. Senior capstone project: a real-time anomaly detection system using streaming data and a lightweight ML pipeline.
