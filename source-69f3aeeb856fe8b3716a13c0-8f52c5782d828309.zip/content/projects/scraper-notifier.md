---
title: "Web Scraper & Notifier"
description: "A lightweight Python scraper that monitors target websites for changes (price drops, new listings, keyword appearances) and sends notifications via email or Slack webhook. Configurable via a simple YAML file."
tags: ["Python", "BeautifulSoup", "Requests", "Slack API", "Automation"]
github: "https://github.com/your-username/scraper-notifier"
liveUrl: ""
---

Built out of frustration with manually checking websites for updates. The scraper runs on a cron schedule, diffs the current page content against a stored snapshot, and fires a Slack or email notification when a change is detected. Supports CSS selector–based targeting and optional regex filtering.
