---
title: "ML Experiment Tracker (CLI)"
description: "A command-line tool for tracking machine learning experiments locally — logs hyperparameters, metrics, and artifact paths to a SQLite database and renders a comparison table in the terminal. A lightweight alternative to MLflow for quick prototyping."
tags: ["Python", "Scikit-learn", "SQLite", "CLI", "Machine Learning"]
github: "https://github.com/your-username/ml-experiment-tracker"
liveUrl: ""
---

Inspired by the overhead of setting up full MLOps platforms for simple weekend projects. The CLI lets you log an experiment (`track run --params lr=0.01`), list all runs, compare metrics across runs, and export results to CSV. Built with Click for the CLI layer and SQLite for zero-dependency persistence.
