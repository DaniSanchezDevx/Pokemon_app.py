---
title: "Data Pipeline Dashboard"
description: "An end-to-end data pipeline that ingests CSV exports, cleans and transforms the data with Pandas, stores results in PostgreSQL, and serves a simple dashboard showing key metrics. Containerized with Docker for easy deployment."
tags: ["Python", "Pandas", "PostgreSQL", "Docker", "Data Engineering"]
github: "https://github.com/your-username/data-pipeline-dashboard"
liveUrl: ""
---

A personal project to practice building a complete data engineering workflow. Raw CSV files are dropped into a watched directory, automatically processed by a Python script, and loaded into a local Postgres database. A minimal frontend displays aggregated metrics updated in near-real time.
